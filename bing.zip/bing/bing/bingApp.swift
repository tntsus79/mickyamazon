//
//  bingApp.swift
//  bing
//
//  Created by Myles Holley on 1/19/23.
//

import SwiftUI

@main
struct bingApp: App {
    var body: some Scene {
        WindowGroup {
            homeview()
        }
    }
}
