//
//  gameview.swift
//  bing
//
//  Created by Myles Holley on 1/19/23.
//

import SwiftUI

struct gameview: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}


